# WebProject : ByteCoin

     
팀원 | 분업
------------ | -------------
권태준 | html+css / Server
김혜은 | html+css / JS
김휘람 | html+css / JS

- [ ] 기본 레이아웃 제작
- [x] Open API 파싱 
- [ ] 특정 스크립트 새로고침
- [ ] 회원가입 / 로그인 구현
- [ ] 게시판 구현
- [ ] Flask / Apache 연동
- [ ] Flask / MariaDB 연동
- [x] Flask / gunicorn / nginx 연동
- [x] 호스팅 [호스팅 주소: http://bytecoin.site ]
- [ ] 완료보고서(작성중) [주소: https://docs.google.com/document/d/1dSDN7aD97M9XGEUttT2R_wX1uZc2gWVOfctEsQ4KmFA/edit#]
